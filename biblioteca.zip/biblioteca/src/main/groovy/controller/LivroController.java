package controller;

import model.LivroModel;
import repository.LivroRepository;

import java.time.LocalDate;
import java.util.List;

public class LivroController {

    private LivroRepository livroRepository;


    public LivroController() {
        this.livroRepository = new LivroRepository();
    }


    public boolean salvarLivro(Long id, String titulo, String tema, String autor, String isbn, LocalDate dataPublicacao, int qtdDisponivel) {


        if (titulo == null || titulo.trim().isEmpty()) {
            System.err.println("Erro: O título não pode estar vazio.");
            return false;
        }
        if (autor == null || autor.trim().isEmpty()) {
            System.err.println("Erro: O autor não pode estar vazio.");
            return false;
        }
        if (isbn == null || isbn.trim().isEmpty()) {
            System.err.println("Erro: O ISBN não pode estar vazio.");
            return false;
        }

        if (qtdDisponivel < 0) {
            System.err.println("Erro: A quantidade disponível não pode ser negativa.");
            return false;
        }



        LivroModel livro = new LivroModel();
        livro.setId(id);
        livro.setTitulo(titulo);
        livro.setTema(tema);
        livro.setAutor(autor);
        livro.setIsbn(isbn);
        livro.setDataPublicacao(dataPublicacao);
        livro.setQtdDisponivel(qtdDisponivel);

        try {

            livroRepository.salvar(livro);
            return true;
        } catch (Exception e) {
            System.err.println("Erro ao salvar livro no controller: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    public boolean excluirLivro(Long id) {
        if (id == null) {
            System.err.println("Erro: ID do livro não pode ser nulo para exclusão.");
            return false;
        }
        try {
            livroRepository.excluir(id);
            return true;
        } catch (Exception e) {
            System.err.println("Erro ao excluir livro: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    public LivroModel buscarLivroPorId(Long id) {
        return livroRepository.buscarPorId(id);
    }


    public List<LivroModel> listarTodosLivros() {
        return livroRepository.listarTodos();
    }


    public List<LivroModel> listarLivrosDisponiveis() {
        return livroRepository.listarDisponiveis();
    }

    public List<LivroModel> buscarLivrosPorTitulo(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            return listarTodosLivros();
        }
        return livroRepository.buscarPorTitulo(titulo);
    }
}