package view;

import controller.LivroController;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class CadastrarLivro {
    private JPanel PainelCadastro;
    private JTextField textTitulo;
    private JTextField textTema;
    private JTextField textAutor;
    private JTextField textISBN;
    private JButton CadastroButton;
    private JTextField textPublicacao;
    private JTextField textQuantidade;
    private JTextField textIdentificacao; // ID

    private LivroController livroController;


    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public CadastrarLivro() {
        this.livroController = new LivroController();

        CadastroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarLivro();
            }
        });


        textIdentificacao.setEnabled(false);
    }

    private void salvarLivro() {
        String titulo = textTitulo.getText();
        String tema = textTema.getText();
        String autor = textAutor.getText();
        String isbn = textISBN.getText();

        LocalDate dataPublicacao;
        int qtdDisponivel;
        Long id = null;


        try {

            qtdDisponivel = Integer.parseInt(textQuantidade.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(PainelCadastro, "Erro: A Quantidade deve ser um número.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {

            dataPublicacao = LocalDate.parse(textPublicacao.getText(), dateFormatter);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(PainelCadastro, "Erro: Formato da Data de Publicação inválido.\nUse o formato dd/MM/yyyy.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!textIdentificacao.getText().trim().isEmpty()) {
            try {
                id = Long.parseLong(textIdentificacao.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(PainelCadastro, "Erro: ID inválido.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }


        boolean sucesso = livroController.salvarLivro(id, titulo, tema, autor, isbn, dataPublicacao, qtdDisponivel);


        if (sucesso) {
            JOptionPane.showMessageDialog(PainelCadastro, "Livro salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            limparCampos();
        } else {

            JOptionPane.showMessageDialog(PainelCadastro, "Erro ao salvar livro.\nVerifique se os campos estão corretos ou se o ISBN já foi cadastrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limparCampos() {
        textIdentificacao.setText("");
        textTitulo.setText("");
        textTema.setText("");
        textAutor.setText("");
        textISBN.setText("");
        textPublicacao.setText("");
        textQuantidade.setText("");
    }

    public JPanel getPainelCadastro() {
        return PainelCadastro;
    }
}