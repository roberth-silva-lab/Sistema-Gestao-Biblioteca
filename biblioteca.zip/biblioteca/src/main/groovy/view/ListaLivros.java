package view;

// 1. Importar Controllers e Models
import controller.EmprestimoController;
import controller.LivroController;
import model.EmprestimoModel;
import model.LivroModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel; // Importar TableModel
import java.time.format.DateTimeFormatter; // Para formatar datas
import java.util.List;

public class ListaLivros {
    private JPanel PaneListar;
    private JTable tableDisponiveis;
    private JTable tableEmprestados;

    // 2. Declarar Controllers
    private LivroController livroController;
    private EmprestimoController emprestimoController;

    // 3. Declarar TableModels
    private DefaultTableModel disponiveisTableModel;
    private DefaultTableModel emprestadosTableModel;

    // Formato de data para exibição
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ListaLivros() {
        // 4. Instanciar Controllers
        this.livroController = new LivroController();
        this.emprestimoController = new EmprestimoController();

        // 5. Configurar as tabelas
        configurarTabelas();

        // 6. Carregar os dados nas tabelas
        carregarLivrosDisponiveis();
        carregarLivrosEmprestados();
    }

    /**
     * Define as colunas de ambas as tabelas.
     */
    private void configurarTabelas() {
        // Tabela de Livros Disponíveis
        String[] colunasDisponiveis = {"ID Livro", "Título", "Autor", "Qtd. Disponível"};
        disponiveisTableModel = new DefaultTableModel(colunasDisponiveis, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Não editável
            }
        };
        tableDisponiveis.setModel(disponiveisTableModel);

        // Tabela de Livros Emprestados (Ativos)
        String[] colunasEmprestados = {"ID Empr.", "Livro", "Aluno", "Data Empréstimo", "Data Prevista"};
        emprestadosTableModel = new DefaultTableModel(colunasEmprestados, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Não editável
            }
        };
        tableEmprestados.setModel(emprestadosTableModel);
    }

    /**
     * Busca livros com estoque > 0 e preenche a tabela tableDisponiveis.
     */
    private void carregarLivrosDisponiveis() {
        List<LivroModel> livros = livroController.listarLivrosDisponiveis();

        // Limpa a tabela
        disponiveisTableModel.setRowCount(0);

        for (LivroModel livro : livros) {
            disponiveisTableModel.addRow(new Object[]{
                    livro.getId(),
                    livro.getTitulo(),
                    livro.getAutor(),
                    livro.getQtdDisponivel()
            });
        }
    }

    /**
     * Busca todos os empréstimos ativos (dataDevolucaoReal IS NULL)
     * e preenche a tabela tableEmprestados.
     */
    private void carregarLivrosEmprestados() {
        // Usamos o método com JOIN FETCH que corrigimos no repositório
        List<EmprestimoModel> emprestimos = emprestimoController.listarTodosEmprestimosAtivos();

        // Limpa a tabela
        emprestadosTableModel.setRowCount(0);

        for (EmprestimoModel emprestimo : emprestimos) {
            emprestadosTableModel.addRow(new Object[]{
                    emprestimo.getId(),
                    emprestimo.getLivro().getTitulo(),
                    emprestimo.getAluno().getNome(),
                    emprestimo.getDataEmprestimo().format(dateFormatter),
                    emprestimo.getDataDevolucaoPrevista().format(dateFormatter)
            });
        }
    }

    public JPanel getPaneListar() {
        return PaneListar;
    }
}