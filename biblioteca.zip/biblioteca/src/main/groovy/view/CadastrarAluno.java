package view;

import controller.AlunoController;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastrarAluno {
    private JTextField textNome;
    private JTextField textSexo;
    private JTextField textCelular;
    private JTextField textEmail;
    private JTextField textAlunoId;
    private JButton buttonCadastroAluno;
    private JPanel PainelAluno;

    private AlunoController alunoController;

    public CadastrarAluno() {
        this.alunoController = new AlunoController();


        buttonCadastroAluno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarAluno(); // 5. Chamar o método de salvar
            }
        });


        textAlunoId.setEnabled(false);
    }


    private void salvarAluno() {

        String nome = textNome.getText();
        String sexo = textSexo.getText();
        String celular = textCelular.getText();
        String email = textEmail.getText();
        Long id = null;


        if (!textAlunoId.getText().trim().isEmpty()) {
            try {
                id = Long.parseLong(textAlunoId.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(PainelAluno, "Erro: ID inválido.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }


        boolean sucesso = alunoController.salvarAluno(id, nome, sexo, celular, email);


        if (sucesso) {
            JOptionPane.showMessageDialog(PainelAluno, "Aluno salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            limparCampos(); // Limpa a tela
        } else {

            JOptionPane.showMessageDialog(PainelAluno, "Erro ao salvar aluno.\nVerifique se os campos estão corretos ou se o e-mail já foi cadastrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limparCampos() {
        textAlunoId.setText("");
        textNome.setText("");
        textSexo.setText("");
        textCelular.setText("");
        textEmail.setText("");
    }

    public JPanel getPainelCadastroAluno() {
        return PainelAluno;
    }
}